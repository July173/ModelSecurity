﻿// Seeing this comment implies that the code generation for file 'C:\Users\Asus\source\repos\Autogestion-Sena\Diagram2\DbAutogestion.edmx'
// failed. See the ErrorList for details.